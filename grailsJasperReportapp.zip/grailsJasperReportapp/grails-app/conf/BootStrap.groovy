class BootStrap {

    def init = { servletContext ->
        new Book(title:'agile modeling', author:'Scott W. Ambler', publisher:'Whiley Computer Publishing', category:'Modeling').save()
        new Book(title:'The J2EE Architect\'s Handbook', author:'Derek C. Ashmore', publisher:'DVT Press', category:'Architecture').save()
        new Book(title:'Getting Started with Grails', author:'Jason Rudolph', publisher:'InfoQ', category:'Programming').save()
    }
    def destroy = {
    }
} 