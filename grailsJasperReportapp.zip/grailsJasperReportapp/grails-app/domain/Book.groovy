class Book {
    String title
    String author
    String publisher
    String category

    static constraints={
        // to get it in the order I want in views
        title()
        author()
        publisher()
        category()
    }
}
